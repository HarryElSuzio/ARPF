resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'ARPF by Peter Greek (Xerxes468893) made for BCDOJRP Released to the Public' -- Do not Remove

client_scripts {
  'client/civ.lua'
}

server_scripts {
  'server/server.lua'
}
